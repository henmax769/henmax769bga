# Arduino-Timer-Count-Down-Switch-Automatic
Project Timer Counter Down for Switch OFF using Arduino Nano
